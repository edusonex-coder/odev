import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Camera, Upload, Send, X, Image as ImageIcon, Loader2, Sparkles, Wand2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { getAIResponse, analyzeQuestionImage } from "@/lib/ai";
import Tesseract from 'tesseract.js';
import { compressImage } from "@/lib/imageUtils";

export default function AskQuestion() {
  const [questionText, setQuestionText] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const { toast } = useToast();
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  // Taslağı Yerel Depolamadan Yükle
  useEffect(() => {
    const savedText = localStorage.getItem("ask_question_draft_text");
    const savedSubject = localStorage.getItem("ask_question_draft_subject");
    if (savedText) setQuestionText(savedText);
    if (savedSubject) setSelectedSubject(savedSubject);
  }, []);

  // Taslağı Otomatik Kaydet
  useEffect(() => {
    localStorage.setItem("ask_question_draft_text", questionText);
    localStorage.setItem("ask_question_draft_subject", selectedSubject);
  }, [questionText, selectedSubject]);

  // Kamera akışını yöneten Effect
  useEffect(() => {
    if (showCamera && videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(err => console.error("Video oynatma hatası:", err));
    }
  }, [showCamera, stream]);

  // Component unmount olduğunda kamerayı kapat
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  const processImageOCR = async (file: File) => {
    setIsProcessing(true);
    toast({
      title: "Yazı Okunuyor 📖",
      description: "Yapay Zeka sorunuzu analiz ediyor...",
    });

    try {
      // 1. Dosyayı Base64'e çevir (AI Vision için)
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
      const base64Image = await base64Promise;

      // 2. AI Vision ile OCR yap
      const text = await analyzeQuestionImage(base64Image, profile?.tenant_id || undefined);

      if (text && !text.startsWith("HATA:")) {
        setQuestionText(text); // Replacement is better for "Ask Question" flow to avoid mixing old question text
        toast({
          title: "Başarılı ✨",
          description: "Yapay zeka soruyu başarıyla okudu.",
          duration: 3000,
        });
      } else {
        // AI Vision başarısız olursa Tesseract'a düş (Fallback)
        console.warn("AI Vision failed or returned error:", text);
        toast({
          title: "AI Okuyamadı",
          description: "Geleneksel yöntem (OCR) deneniyor...",
        });

        const result = await Tesseract.recognize(file, 'tur');
        const fallbackText = result.data.text.trim();

        if (fallbackText) {
          setQuestionText(fallbackText);
        } else {
          throw new Error("Metin bulunamadı.");
        }
      }
    } catch (error: any) {
      console.error("OCR Hatası (Kritik):", error);
      toast({
        title: "Okuma Hatası",
        description: `Metin okunamadı (${error?.message || "Bilinmiyor"}), lütfen elle yazın.`,
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsProcessing(true);
      try {
        const compressedFile = await compressImage(file);

        const reader = new FileReader();
        reader.onloadend = () => {
          setImage(reader.result as string);
          setImageFile(compressedFile);
          // Otomatik OCR başlat
          processImageOCR(compressedFile);
        };
        reader.readAsDataURL(compressedFile);
      } catch (err) {
        console.error("Image processing error:", err);
        setIsProcessing(false);
      }
    }
  };

  const startCamera = async () => {
    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment', // Arka kamera öncelikli
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      });
      setStream(newStream);
      setShowCamera(true);
    } catch (err) {
      console.error("Kamera erişim hatası:", err);
      toast({
        title: "Kamera hatası",
        description: "Kameraya erişilemedi. Lütfen izinleri kontrol edin.",
        variant: "destructive",
      });
    }
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement("canvas");
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvas.toDataURL("image/jpeg");
        setImage(dataUrl);

        // DataURL'i dosyaya çevir ve SIKIŞTIR
        fetch(dataUrl)
          .then(res => res.blob())
          .then(async blob => {
            const file = new File([blob], "camera-photo.jpg", { type: "image/jpeg" });
            const compressedFile = await compressImage(file);
            setImageFile(compressedFile);
            // Otomatik OCR başlat
            processImageOCR(compressedFile);
          });

        stopCamera();
      }
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setShowCamera(false);
  };

  const removeImage = () => {
    setImage(null);
    setImageFile(null);
    setQuestionText(""); // Clear OCR text too when image is removed
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const clearText = () => {
    setQuestionText("");
    localStorage.removeItem("ask_question_draft_text");
  };

  const handleSubmit = async () => {
    if (!questionText && !imageFile) {
      toast({
        title: "Eksik bilgi",
        description: "Lütfen bir soru yazın veya fotoğraf yükleyin.",
        variant: "destructive",
      });
      return;
    }

    if (!selectedSubject) {
      toast({
        title: "Ders seçimi",
        description: "Lütfen bir ders seçin.",
        variant: "destructive",
      });
      return;
    }

    try {
      let imageUrl = null;

      // 1. Resmi Supabase Storage'a yükle (Varsa)
      if (imageFile) {
        toast({ title: "Yükleniyor...", description: "Resim sunucuya gönderiliyor." });
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `${user?.id}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('question_images')
          .upload(filePath, imageFile);

        if (uploadError) throw new Error(`Resim yükleme hatası: ${uploadError.message}`);
        imageUrl = filePath;
      }

      // 2. Soruyu veritabanına kaydet
      const { data: qData, error: dbError } = await supabase
        .from('questions')
        .insert({
          student_id: user?.id,
          question_text: questionText,
          image_url: imageUrl,
          subject: selectedSubject,
          status: 'pending' // Varsayılan
        })
        .select()
        .single();

      if (dbError) throw new Error(`Veritabanı kayıt hatası: ${dbError.message}`);

      // 3. EĞER METİN VARSA: AI Otomatik Çözüm Üretsin
      if (questionText && qData) {
        try {
          toast({
            title: "Yapay Zeka Çalışıyor �",
            description: "Sorunuz analiz ediliyor, lütfen bekleyin...",
            duration: 3000,
          });

          const aiPrompt = `Öğrenci sorusu (${selectedSubject}): ${questionText}. 
          Lütfen bu soruyu adım adım, açıklayıcı ve eğitici bir dille çöz. 
          Cevabı doğrudan verme, önce ipucu ver sonra çözümü anlat. Türkçe kullan.`;

          const aiResponseText = await getAIResponse(
            [{ role: "user", content: aiPrompt }],
            profile?.tenant_id || undefined,
            undefined, // no personality prompt override here
            "homework_solver",
            qData.id // Pass questionId here!
          );

          // Çözümü kaydet
          const { error: insertError } = await supabase.from("solutions").insert({
            question_id: qData.id,
            solver_type: "ai",
            solver_id: user?.id,
            solution_text: aiResponseText
          });

          if (insertError) throw insertError;

          toast({
            title: "Çözüm Hazır! 🎉",
            description: "Yapay zeka sorunu çözdü.",
            duration: 3000,
          });

          // Soru durumunu güncelle
          await supabase.from("questions").update({ status: "ai_answered" }).eq("id", qData.id);

        } catch (aiError: any) {
          console.error("AI Auto-Solve Hatası:", aiError);
          toast({
            title: "Otomatik Çözüm Hatası",
            description: "Hata detayı: " + (aiError?.message || aiError?.toString() || "Bilinmiyor"),
            variant: "destructive",
            duration: 10000, // 10 saniye ekranda kalsın
          });
          // Hata olsa bile soru kaydedildi, devam et.
        }
      }

      toast({
        title: "Soru Gönderildi! 🚀",
        description: "Sorunuz ve (varsa) AI çözümü hazır.",
      });

      // Temizle ve yönlendir => History sayfasına gidip sonucu görsün
      setQuestionText("");
      setSelectedSubject("");
      localStorage.removeItem("ask_question_draft_text");
      localStorage.removeItem("ask_question_draft_subject");
      setImage(null);
      setImageFile(null);
      navigate("/dashboard/history");

    } catch (error: any) {
      console.error(error);
      toast({
        title: "Hata",
        description: error.message || "Soru gönderilemedi.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold mb-1">Soru Sor</h1>
        <p className="text-muted-foreground text-sm">Fotoğrafını çek, yapay zeka çözsün.</p>
      </motion.div>

      <div className="space-y-4">
        {/* Fotoğraf Alanı */}
        <div className="relative">
          {showCamera ? (
            <div className="relative rounded-xl overflow-hidden bg-black aspect-video">
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-4">
                <Button onClick={stopCamera} variant="secondary" size="icon" className="rounded-full w-12 h-12">
                  <X className="w-6 h-6" />
                </Button>
                <Button onClick={capturePhoto} size="icon" className="rounded-full w-16 h-16 border-4 border-white bg-transparent hover:bg-white/20">
                  <div className="w-12 h-12 rounded-full bg-white" />
                </Button>
              </div>
            </div>
          ) : (
            <div className="bg-card border-2 border-dashed rounded-xl p-8 text-center hover:border-primary/50 transition-colors relative">
              {image ? (
                <div className="relative inline-block">
                  <img src={image} alt="Preview" className="max-h-64 rounded-lg shadow-lg" />
                  <Button
                    onClick={removeImage}
                    variant="destructive"
                    size="icon"
                    className="absolute -top-2 -right-2 rounded-full w-8 h-8 shadow-md"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                  {isProcessing && (
                    <div className="absolute inset-0 bg-black/50 rounded-lg flex flex-col items-center justify-center text-white backdrop-blur-sm">
                      <Loader2 className="w-8 h-8 animate-spin mb-2" />
                      <span className="text-sm font-medium animate-pulse">Yazı Okunuyor...</span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto animate-pulse-glow">
                    <Camera className="w-8 h-8 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Fotoğraf Yükle veya Çek</h3>
                    <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                      Sorunun net bir fotoğrafını çek. Yapay zeka senin için okuyacak.
                    </p>
                  </div>
                  <div className="flex justify-center gap-3 pt-2">
                    <Button onClick={() => fileInputRef.current?.click()} variant="outline" className="gap-2">
                      <Upload className="w-4 h-4" /> Galeri
                    </Button>
                    <Button onClick={startCamera} className="gap-2 gradient-primary text-primary-foreground shadow-glow">
                      <Camera className="w-4 h-4" /> Kamera
                    </Button>
                  </div>
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageChange}
                  />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Metin Alanı */}
        <div className="space-y-2 relative">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Soru Metni</label>
            <div className="flex gap-2">
              {questionText && (
                <button
                  onClick={clearText}
                  className="text-xs text-muted-foreground hover:text-destructive transition-colors"
                >
                  Temizle
                </button>
              )}
              {isProcessing && (
                <span className="text-xs text-primary flex items-center gap-1 animate-pulse">
                  <Wand2 className="w-3 h-3" /> Fotoğraftan metin çıkarılıyor...
                </span>
              )}
            </div>
          </div>
          <Textarea
            placeholder="Sorunu buraya yazabilir veya fotoğraf çekebilirsin..."
            value={questionText}
            onChange={(e) => setQuestionText(e.target.value)}
            className={`min-h-[120px] rounded-xl resize-none p-4 text-base transition-all duration-300 ${isProcessing ? "border-primary ring-1 ring-primary/20 bg-primary/5" : ""
              }`}
          />
        </div>

        {/* Ders Seçimi */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Ders</label>
          <Select onValueChange={setSelectedSubject} value={selectedSubject}>
            <SelectTrigger className="w-full rounded-xl h-12">
              <SelectValue placeholder="Ders Seçin" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="matematik">Matematik</SelectItem>
              <SelectItem value="fen">Fen Bilimleri</SelectItem>
              <SelectItem value="turkce">Türkçe</SelectItem>
              <SelectItem value="sosyal">Sosyal Bilgiler</SelectItem>
              <SelectItem value="ingilizce">İngilizce</SelectItem>
              <SelectItem value="fizik">Fizik</SelectItem>
              <SelectItem value="kimya">Kimya</SelectItem>
              <SelectItem value="biyoloji">Biyoloji</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button
          className="w-full py-6 text-lg font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300"
          size="lg"
          onClick={handleSubmit}
          disabled={(!questionText && !image) || !selectedSubject || isProcessing}
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
              İşleniyor...
            </>
          ) : (
            <>
              <Send className="w-5 h-5 mr-2" />
              Soruyu Gönder
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
