import { motion } from "framer-motion";
import { useNavigate, Link } from "react-router-dom";
import {
  Camera,
  BookOpen,
  Trophy,
  TrendingUp,
  Flame,
  Star,
  ChevronRight,
  Loader2,
  Calendar,
  Zap,
  Target,
  Clock,
  CheckCircle2,
  School,
  Sparkles,
  MoreVertical,
  LogOut,
  Wand2,
  Megaphone,
  Bell,
  Users
} from "lucide-react";
import SmartReminders from "@/components/SmartReminders";
import { SocraticQuizCard } from "@/components/SocraticQuizCard";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { useEffect, useState } from "react";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/lib/supabase";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import SEO from "@/components/SEO";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface Assignment {
  id: string;
  title: string;
  description: string;
  due_date: string;
  status: string;
  submitted_at?: string;
  grade?: number;
  feedback?: string;
}

interface Announcement {
  id: string;
  title: string;
  content: string;
  type: string;
  is_global: boolean;
  created_at: string;
}

// Mock Data - Haftalık Çalışma (Yedek)
const defaultActivityData = [
  { name: 'Pzt', puan: 0 },
  { name: 'Sal', puan: 0 },
  { name: 'Çar', puan: 0 },
  { name: 'Per', puan: 0 },
  { name: 'Cum', puan: 0 },
  { name: 'Cmt', puan: 0 },
  { name: 'Paz', puan: 0 },
];

interface UserClass {
  id: string;
  class_id: string;
  classes: {
    id: string;
    name: string;
    color: string;
    schedule: string | null;
    profiles: {
      full_name: string | null;
    } | null;
  } | null;
}

export default function DashboardHome() {
  const { profile, loading, user } = useAuth();
  const { tenant } = useTenant();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [joinCode, setJoinCode] = useState("");
  const [joining, setJoining] = useState(false);
  const [userClasses, setUserClasses] = useState<UserClass[]>([]);
  const [classesLoading, setClassesLoading] = useState(true);
  const [stats, setStats] = useState({ solved: 0, streak: 0, success: 0 });
  const [weeklyXp, setWeeklyXp] = useState<any[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [assignmentsLoading, setAssignmentsLoading] = useState(true);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [dailyQuest, setDailyQuest] = useState({ questions: 0, chats: 0, claimed: false });

  // Gamification stats from real profile data
  const currentXp = profile?.xp || 0;
  const currentLevel = profile?.level || 1;
  const nextLevelXp = currentLevel * 1000;
  const progressToNextLevel = ((currentXp % 1000) / 1000) * 100;

  const [badges, setBadges] = useState<any[]>([]);
  const [badgesLoading, setBadgesLoading] = useState(true);

  useEffect(() => {
    if (!loading && profile) {
      if (profile.role === 'teacher') {
        navigate('/teacher');
      } else if (profile.role === 'admin') {
        navigate('/dashboard/admin');
      } else if (profile.role === 'parent') {
        navigate('/dashboard/parent', { replace: true });
      } else {
        fetchUserClasses();
        fetchUserStats();
        fetchAssignments();
        fetchAnnouncements();
        fetchUserBadges();
      }
    }
  }, [profile, loading, navigate]);

  const fetchUserBadges = async () => {
    if (!profile?.id) return;
    try {
      setBadgesLoading(true);
      // 1. Tüm rozetleri çek
      const { data: allBadges } = await supabase.from('badges').select('*').limit(6);
      // 2. Kazanılanları çek
      const { data: userBadges } = await supabase.from('user_badges').select('badge_id').eq('user_id', profile.id);

      const earnedIds = new Set(userBadges?.map(ub => ub.badge_id));
      const combined = (allBadges || []).map(b => ({
        ...b,
        earned: earnedIds.has(b.id)
      }));
      setBadges(combined);
    } catch (e) {
      console.error("Badges error:", e);
    } finally {
      setBadgesLoading(false);
    }
  };

  const fetchAnnouncements = async () => {
    if (!profile?.tenant_id) return;
    try {
      const { data, error } = await supabase
        .from("announcements")
        .select("*")
        .or(`tenant_id.eq.${profile.tenant_id},is_global.eq.true`)
        .eq("is_active", true)
        .order("created_at", { ascending: false })
        .limit(3);

      if (error) throw error;
      setAnnouncements(data || []);
    } catch (err) {
      console.error("Announcements error:", err);
    }
  };

  const fetchUserStats = async () => {
    if (!user) return;
    try {
      // Soru sayısı
      const { count } = await supabase
        .from('questions')
        .select('*', { count: 'exact', head: true })
        .eq('student_id', user.id);

      setStats(prev => ({
        ...prev,
        solved: count || 0,
        streak: profile?.streak || 0
      }));

      // Günlük görev durumunu çek
      const { data: questData } = await supabase.rpc('get_daily_quest_status', { p_student_id: user.id });
      if (questData && questData[0]) {
        setDailyQuest({
          questions: questData[0].questions_solved,
          chats: questData[0].socratic_chats,
          claimed: questData[0].is_bonus_claimed
        });
      }

      // Haftalık XP grafiği için RPC fonksiyonunu kullan (get_student_daily_xp)
      const { data: xpData } = await supabase
        .rpc('get_student_daily_xp', {
          p_student_id: user.id,
          p_days: 7
        });

      setWeeklyXp(xpData ? xpData.map((d: any) => ({ name: d.day_name, puan: d.total_xp })) : defaultActivityData);
    } catch (err) {
      console.error("Stats fetching error:", err);
      setWeeklyXp(defaultActivityData);
    }
  };

  const handleClaimBonus = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase.rpc('claim_daily_quest_bonus', { p_student_id: user.id });
      if (error) throw error;

      if (data.success) {
        toast({ title: "Tebrikler! 🎉", description: data.message });
        setDailyQuest(prev => ({ ...prev, claimed: true }));
        fetchUserStats(); // XP güncellensin
      } else {
        toast({ title: "Bilgi", description: data.message, variant: "destructive" });
      }
    } catch (error: any) {
      toast({ title: "Hata", description: "Ödül alınırken bir sorun oluştu.", variant: "destructive" });
    }
  };

  const fetchAssignments = async () => {
    if (!user) return;
    try {
      setAssignmentsLoading(true);

      // 1. Önce öğrencinin sınıflarını al
      const { data: userClassList } = await supabase
        .from('class_students')
        .select('class_id')
        .eq('student_id', user.id);

      const classIds = userClassList?.map(c => c.class_id) || [];

      if (classIds.length === 0) {
        setAssignments([]);
        return;
      }

      // 2. Bu sınıflara ait TÜM ödevleri çek
      const { data: assignmentsData, error: assignError } = await supabase
        .from('assignments')
        .select(`
            id,
            title,
            description,
            due_date
        `)
        .in('class_id', classIds)
        .order('due_date', { ascending: true })
        .limit(10);

      if (assignError) throw assignError;

      if (!assignmentsData || assignmentsData.length === 0) {
        setAssignments([]);
        return;
      }

      // 3. Öğrencinin teslim durumlarını çek
      const assignmentIds = assignmentsData.map(a => a.id);
      const { data: submissionsData, error: subError } = await supabase
        .from('assignment_submissions')
        .select('assignment_id, status, score, submitted_at, feedback')
        .eq('student_id', user.id)
        .in('assignment_id', assignmentIds);

      if (subError) throw subError;

      // 4. Verileri birleştir
      const combinedAssignments = assignmentsData.map((assign: any) => {
        const sub = submissionsData?.find((s: any) => s.assignment_id === assign.id);

        let status = 'pending';
        // Hiç submission yoksa -> pending (Ödev Bekliyor)
        // Submission var, status 'pending' -> submitted (Teslim Edildi, Not Bekliyor)
        // Submission var, status 'graded' -> graded (Notlandı)

        if (sub) {
          if (sub.status === 'graded') status = 'graded';
          else status = 'submitted';
        }

        return {
          id: assign.id,
          title: assign.title,
          description: assign.description,
          due_date: assign.due_date,
          status: status,
          submitted_at: sub?.submitted_at,
          grade: sub?.score,
          feedback: sub?.feedback
        };
      });

      // 5. Sıralama: Yapılmamışlar en üstte
      combinedAssignments.sort((a, b) => {
        const statusOrder: Record<string, number> = { pending: 0, submitted: 1, graded: 2 };
        return (statusOrder[a.status] || 0) - (statusOrder[b.status] || 0);
      });

      setAssignments(combinedAssignments);

    } catch (err) {
      console.error("Assignments fetch error:", err);
    } finally {
      setAssignmentsLoading(false);
    }
  };

  const fetchUserClasses = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('class_students')
        .select(`
          id,
          class_id,
          classes (
            id,
            name,
            color,
            schedule,
            profiles:teacher_id (
              full_name
            )
          )
        `)
        .eq('student_id', user.id);

      if (error) throw error;

      // Fix typing issue with Supabase join
      const formattedData = data?.map(item => ({
        ...item,
        classes: Array.isArray(item.classes) ? item.classes[0] : item.classes
      })) as any;

      setUserClasses(formattedData || []);
    } catch (error) {
      console.error("Sınıflar yüklenirken hata:", error);
    } finally {
      setClassesLoading(false);
    }
  };

  const handleJoinClass = async () => {
    if (!joinCode.trim() || !user) return;
    setJoining(true);

    try {
      // 1. Kodu kontrol et (Güvenli Köprü üzerinden)
      const { data: classData, error: classError } = await supabase
        .rpc('get_class_by_invite_code', { p_code: joinCode.toUpperCase() });

      if (classError || !classData || classData.length === 0) {
        throw new Error("Geçersiz davet kodu. Lütfen kontrol edip tekrar deneyin.");
      }

      const TargetClass = classData[0];

      // 2. Halihazırda üye mi kontrol et
      const { data: existingMember } = await supabase
        .from('class_students')
        .select('id')
        .eq('class_id', TargetClass.id)
        .eq('student_id', user.id)
        .maybeSingle();

      if (existingMember) {
        throw new Error("Zaten bu sınıfın bir üyesisin! 😊");
      }

      // 3. Sınıfa ekle
      const { error: joinError } = await supabase
        .from('class_students')
        .insert({
          class_id: TargetClass.id,
          student_id: user.id
        });

      if (joinError) throw joinError;

      toast({
        title: "Harika! 🎉",
        description: `${TargetClass.name} sınıfına başarıyla katıldın. Hoş geldin!`,
      });
      setJoinCode("");
      fetchUserClasses(); // Refresh classes

    } catch (error: any) {
      toast({
        title: "Hata",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setJoining(false);
    }
  };

  const getClassColorBorder = (color: string) => {
    switch (color) {
      case 'blue': return 'border-blue-500';
      case 'green': return 'border-green-500';
      case 'purple': return 'border-purple-500';
      case 'orange': return 'border-orange-500';
      default: return 'border-gray-500';
    }
  };

  const getClassColorBg = (color: string) => {
    switch (color) {
      case 'blue': return 'bg-blue-50 text-blue-700';
      case 'green': return 'bg-green-50 text-green-700';
      case 'purple': return 'bg-purple-50 text-purple-700';
      case 'orange': return 'bg-orange-50 text-orange-700';
      default: return 'bg-gray-50 text-gray-700';
    }
  };

  if (loading) {
    return (
      <div className="space-y-8 pb-10">
        <SEO title="Yükleniyor..." />
        {/* Hero Skeleton */}
        <div className="h-64 rounded-3xl bg-muted animate-pulse" />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Stats Skeleton */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-28 rounded-2xl" />)}
            </div>
            {/* Chart Skeleton */}
            <Skeleton className="h-[300px] rounded-3xl" />
            {/* Classes Skeleton */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2].map(i => <Skeleton key={i} className="h-20 rounded-2xl" />)}
            </div>
          </div>
          <div className="space-y-8">
            <Skeleton className="h-48 rounded-3xl" />
            <Skeleton className="h-48 rounded-3xl" />
          </div>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex flex-col justify-center items-center h-[50vh] gap-4">
        <h2 className="text-xl font-bold">Profil bilgileri yüklenemedi.</h2>
        <p className="text-muted-foreground">Lütfen internet bağlantınızı kontrol edip tekrar deneyin.</p>
        <Button onClick={() => window.location.reload()}>Sayfayı Yenile</Button>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-10">
      <SEO title="Öğrenci Paneli" />

      {/* Hero Section */}
      <div
        className="relative overflow-hidden rounded-3xl bg-indigo-600 text-white shadow-xl"
        style={{
          background: tenant?.primary_color
            ? `linear-gradient(135deg, ${tenant.primary_color}, ${tenant.primary_color}dd)`
            : undefined
        }}
      >
        <div className="relative z-10 p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-4 max-w-lg">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 text-violet-100 bg-white/10 w-fit px-3 py-1 rounded-full text-sm backdrop-blur-sm">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span>{tenant ? `${tenant.name} Kaşifi` : "Hoş geldin, Süper Kahraman!"}</span>
            </motion.div>
            <h1 className="text-3xl md:text-4xl font-bold leading-tight">
              Merhaba, {profile?.full_name?.split(' ')[0] || 'Öğrenci'}! 👋 <br />
              {tenant ? `${tenant.name}'de` : "Bugün"} öğrenmeye hazır mısın?
            </h1>
            <p className="text-violet-100 text-lg opacity-90">
              Seni bekleyen <span className="font-bold text-white">3 yeni görev</span> ve kazanılacak <span className="font-bold text-yellow-300">500 XP</span> var.
            </p>
            <div className="flex gap-3 pt-2">
              <Link to="/dashboard/ask">
                <Button size="lg" className="bg-white text-violet-700 hover:bg-violet-50 font-bold shadow-lg shadow-violet-900/20 border-0">
                  <Camera className="w-5 h-5 mr-2" /> Soru Sor
                </Button>
              </Link>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="lg" variant="outline" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
                    <School className="w-5 h-5 mr-2" /> Sınıfa Katıl
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Sınıfa Katıl</DialogTitle>
                    <DialogDescription>
                      Öğretmeninden aldığın 6 haneli davet kodunu buraya gir.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="flex flex-col gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="joinCode">Davet Kodu</Label>
                      <Input
                        id="joinCode"
                        placeholder="Örn: X1Y2Z3"
                        className="text-center font-mono text-xl tracking-widest uppercase"
                        value={joinCode}
                        onChange={(e) => setJoinCode(e.target.value)}
                        maxLength={6}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      onClick={handleJoinClass}
                      className="w-full bg-violet-600 hover:bg-violet-700 text-white"
                      disabled={joining || joinCode.length < 6}
                    >
                      {joining ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : "Katıl"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="hidden md:flex items-center justify-center relative w-48 h-48">
            <div className="absolute inset-0 bg-white/10 rounded-full animate-pulse"></div>
            <div className="absolute inset-4 bg-white/10 rounded-full backdrop-blur-sm flex flex-col items-center justify-center border border-white/20 shadow-2xl">
              <span className="text-sm font-medium text-violet-200">SEVİYE</span>
              <span className="text-5xl font-black text-white">{currentLevel}</span>
              <span className="text-xs text-violet-200 mt-1">{currentXp} / {nextLevelXp} XP</span>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-64 h-64 bg-fuchsia-500/20 rounded-full blur-3xl"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sol Kolon: İstatistikler, Grafik ve Sınıflar */}
        <div className="lg:col-span-2 space-y-8">

          {/* İstatistik Kartları */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-orange-50/50 border-orange-100 hover:shadow-md transition-all">
              <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                <Flame className="w-8 h-8 text-orange-500 mb-2" />
                <div className="text-2xl font-bold text-gray-800">{profile?.streak || 0} Gün</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Seri</div>
              </CardContent>
            </Card>
            <Card className="bg-blue-50/50 border-blue-100 hover:shadow-md transition-all">
              <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                <Zap className="w-8 h-8 text-blue-500 mb-2" />
                <div className="text-2xl font-bold text-gray-800">{stats.solved}</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Soru</div>
              </CardContent>
            </Card>
            <Card className="bg-green-50/50 border-green-100 hover:shadow-md transition-all">
              <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                <Target className="w-8 h-8 text-green-500 mb-2" />
                <div className="text-2xl font-bold text-gray-800">%{Math.round(progressToNextLevel)}</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Seviye İlerlemesi</div>
              </CardContent>
            </Card>
            <Card className="bg-purple-50/50 border-purple-100 hover:shadow-md transition-all cursor-pointer" onClick={() => navigate('/dashboard/leaderboard')}>
              <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                <Trophy className="w-8 h-8 text-purple-500 mb-2" />
                <div className="text-2xl font-bold text-gray-800">#{stats.solved > 0 ? '12' : '--'}</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Sıralama</div>
              </CardContent>
            </Card>
          </div>

          <SmartReminders assignments={assignments} />

          {/* Grafik */}
          <Card className="shadow-lg border-primary/5">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle className="text-lg font-bold flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-indigo-600" /> Haftalık XP Grafiği
                </CardTitle>
                <CardDescription>Son 7 gündeki öğrenme aktiviten</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="pl-0">
              <div className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={weeklyXp.length > 0 ? weeklyXp : defaultActivityData}>
                    <defs>
                      <linearGradient id="colorPuan" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis hide />
                    <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }} />
                    <Area type="monotone" dataKey="puan" stroke="#8b5cf6" strokeWidth={3} fillOpacity={1} fill="url(#colorPuan)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Bekleyen Ödevler */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-primary" />
                Ödevlerim
              </h3>
              <Badge variant="secondary" className="rounded-full px-3">{assignments.length}</Badge>
            </div>

            {assignmentsLoading ? (
              <div className="space-y-3">
                {[1, 2].map(i => <Skeleton key={i} className="h-20 rounded-2xl" />)}
              </div>
            ) : assignments.length === 0 ? (
              <Card className="border-dashed border-2 py-8 bg-muted/30">
                <CardContent className="flex flex-col items-center justify-center text-center space-y-2">
                  <div className="p-3 bg-muted rounded-full">
                    <CheckCircle2 className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <p className="font-bold">Harika! Bekleyen ödevin yok.</p>
                  <p className="text-xs text-muted-foreground">Şimdilik dinlenebilir veya soru çözebilirsin.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {assignments.map((assignment) => (
                  <Card key={assignment.id} className="hover:shadow-md transition-all border-l-4 border-l-primary group">
                    <CardContent className="p-4 flex justify-between items-center">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-gray-900 group-hover:text-primary transition-colors">
                            {assignment.title}
                          </h4>
                          <Badge
                            variant={
                              assignment.status === 'graded' ? 'default' :
                                assignment.status === 'submitted' ? 'secondary' :
                                  'outline'
                            }
                            className="text-[10px] h-5"
                          >
                            {assignment.status === 'graded' ? 'Notlandı' :
                              assignment.status === 'submitted' ? 'Gönderildi' :
                                'Bekliyor'}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-1">{assignment.description}</p>
                        <div className="flex items-center gap-3 text-[10px] text-muted-foreground font-medium pt-1">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {assignment.due_date ? new Date(assignment.due_date).toLocaleDateString() : 'Tarih yok'}
                          </span>
                          {assignment.grade && (
                            <span className="flex items-center gap-1 text-green-600 font-bold">
                              <Trophy className="w-3 h-3" />
                              {assignment.grade} Puan
                            </span>
                          )}
                        </div>
                      </div>
                      <Link to={`/dashboard/assignment/${assignment.id}`}>
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0 rounded-full bg-muted/50 group-hover:bg-primary group-hover:text-white transition-all">
                          <ChevronRight className="w-4 h-4" />
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Sınıflarım */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gray-800">Kayıtlı Sınıfların</h3>
            {classesLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[1, 2].map(i => <div key={i} className="h-24 rounded-2xl bg-gray-100 animate-pulse"></div>)}
              </div>
            ) : userClasses.length === 0 ? (
              <div className="p-10 border-2 border-dashed rounded-2xl text-center bg-gray-50/50">
                <p className="text-muted-foreground">Henüz bir sınıfa katılmadın.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {userClasses.map((item) => (
                  <Link key={item.id} to={`/dashboard/class/${item.classes?.id}`}>
                    <Card className={`hover:shadow-md transition-all border-l-4 ${getClassColorBorder(item.classes?.color || 'blue')}`}>
                      <CardContent className="p-4 flex justify-between items-center">
                        <div>
                          <p className="font-bold">{item.classes?.name}</p>
                          <p className="text-xs text-muted-foreground">{item.classes?.profiles?.full_name}</p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-400" />
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Sağ Kolon: Duyurular, Günlük Görevler ve Rozetler */}
        <div className="space-y-8">

          {/* Duyuru Bölümü */}
          {announcements.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between px-2">
                <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                  <Megaphone className="w-4 h-4" /> Duyurular
                </h3>
              </div>
              <div className="space-y-3">
                {announcements.map(announcement => (
                  <Card key={announcement.id} className="border-l-4 border-l-primary overflow-hidden shadow-sm hover:shadow-md transition-all">
                    <CardContent className="p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className={`text-[10px] ${announcement.type === 'urgent' ? 'text-red-600 bg-red-50 border-red-100' :
                          announcement.is_global ? 'text-purple-600 bg-purple-50 border-purple-100' :
                            'text-blue-600 bg-blue-50 border-blue-100'
                          }`}>
                          {announcement.is_global ? 'Global' : 'Kurumsal'}
                        </Badge>
                        <span className="text-[10px] text-muted-foreground">
                          {new Date(announcement.created_at).toLocaleDateString('tr-TR')}
                        </span>
                      </div>
                      <h4 className="font-bold text-sm leading-tight">{announcement.title}</h4>
                      <p className="text-xs text-muted-foreground line-clamp-2">{announcement.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          <Card className="shadow-lg border-indigo-100 bg-indigo-50/30 overflow-hidden">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-600 animate-pulse" /> Günlük Görevler
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-white p-4 rounded-xl border border-indigo-100 space-y-3">
                <div className="flex justify-between items-start">
                  <span className="text-sm font-bold">3 Soru Çöz</span>
                  <Badge variant="secondary" className={cn("font-bold", dailyQuest.questions >= 3 ? "bg-green-100 text-green-700" : "bg-violet-100 text-violet-700")}>
                    {dailyQuest.questions >= 3 ? "✓" : "+50 XP"}
                  </Badge>
                </div>
                <Progress value={(Math.min(dailyQuest.questions, 3) / 3) * 100} className="h-1.5" />
                <p className="text-[10px] text-right font-medium text-gray-500">{Math.min(dailyQuest.questions, 3)}/3</p>
              </div>
              <div className="bg-white p-4 rounded-xl border border-indigo-100 space-y-3">
                <div className="flex justify-between items-start">
                  <span className="text-sm font-bold">1 Sokratik Sohbet</span>
                  <Badge variant="secondary" className={cn("font-bold", dailyQuest.chats >= 1 ? "bg-green-100 text-green-700" : "bg-blue-100 text-blue-700")}>
                    {dailyQuest.chats >= 1 ? "✓" : "+20 XP"}
                  </Badge>
                </div>
                <Progress value={(Math.min(dailyQuest.chats, 1) / 1) * 100} className="h-1.5" />
                <p className="text-[10px] text-right font-medium text-gray-500">{Math.min(dailyQuest.chats, 1)}/1</p>
              </div>
            </CardContent>
            <CardFooter className={cn(
              "p-3 text-center transition-all duration-500",
              dailyQuest.claimed ? "bg-slate-200 text-slate-500" :
                (dailyQuest.questions >= 3 && dailyQuest.chats >= 1) ? "bg-green-600 text-white cursor-pointer hover:bg-green-700" : "bg-indigo-600 text-white"
            )}
              onClick={() => (dailyQuest.questions >= 3 && dailyQuest.chats >= 1 && !dailyQuest.claimed) && handleClaimBonus()}
            >
              <div className="w-full text-[10px] font-black uppercase flex items-center justify-center gap-2">
                {dailyQuest.claimed ? "BUGÜNKÜ HEDİYENİ ALDIN! 🌟" :
                  (dailyQuest.questions >= 3 && dailyQuest.chats >= 1) ? "HEDİYEYİ ALMAK İÇİN TIKLA! 🎁" : "HEPSİNİ TAMAMLA, SÜRPRİZ KUTU KAZAN! 🎁"}
              </div>
            </CardFooter>
          </Card>

          {/* Sokratik Quiz Kartı */}
          <SocraticQuizCard studentId={user?.id || ''} />

          <div className="p-6 rounded-3xl bg-indigo-600 text-white shadow-xl relative overflow-hidden group cursor-pointer" onClick={() => navigate('/dashboard/referral')}>
            <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:scale-110 transition-transform">
              <Users className="w-16 h-16" />
            </div>
            <div className="relative z-10">
              <h3 className="font-black text-xl mb-1 flex items-center gap-2">
                Hediye XP Kazan! 🎁
              </h3>
              <p className="text-xs font-medium opacity-90 mb-4">Arkadaşını davet et, ikiniz de 250 XP kazanın. Hemen başla!</p>
              <Button size="sm" className="w-full bg-white text-indigo-600 hover:bg-gray-100 font-bold border-0">Davet Linkini Al</Button>
            </div>
          </div>

          <Card className="shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                <Trophy className="w-4 h-4 text-yellow-500" /> Rozet Kütüphanesi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-3">
                {badgesLoading ? (
                  [...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)
                ) : badges.length > 0 ? (
                  badges.slice(0, 6).map((badge) => (
                    <div
                      key={badge.id}
                      title={`${badge.name}: ${badge.description}`}
                      className={`flex flex-col items-center justify-center p-2 rounded-xl border transition-all ${badge.earned
                        ? "bg-white border-yellow-100 shadow-sm"
                        : "bg-slate-50 border-slate-100 grayscale opacity-40"
                        }`}
                    >
                      <span className="text-xl mb-1">{badge.icon}</span>
                      <span className="text-[8px] font-black uppercase text-center leading-none">{badge.name}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-[10px] text-muted-foreground text-center col-span-3 py-4">Henüz rozet yok.</p>
                )}
              </div>
            </CardContent>
            <CardFooter className="pt-2">
              <Button
                variant="ghost"
                size="sm"
                className="w-full text-[10px] font-black uppercase tracking-tighter"
                onClick={() => navigate('/dashboard/profile')}
              >
                TÜMÜNE BAK <ChevronRight className="w-3 h-3 ml-1" />
              </Button>
            </CardFooter>
          </Card>

          <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow-xl relative overflow-hidden group">
            <div className="relative z-10">
              <h3 className="font-black text-xl mb-1">PREMIUM</h3>
              <p className="text-xs font-medium opacity-90 mb-4 line-clamp-2">Sınırsız AI kullanımı ve özel içerikler için yükselt.</p>
              <Button size="sm" className="w-full bg-white text-orange-600 hover:bg-gray-100 font-bold">İncele</Button>
            </div>
            <Star className="absolute -bottom-4 -right-4 w-24 h-24 text-white/20 rotate-12 group-hover:scale-110 transition-transform" />
          </div>

        </div>
      </div>
    </div>
  );
}
