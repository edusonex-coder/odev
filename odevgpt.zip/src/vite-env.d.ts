/// <reference types="vite/client" />

interface Window {
    _ai_knowledge_graph_missing?: boolean;
}

declare var globalThis: Window;
