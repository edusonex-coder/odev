import os
import re
import glob

def run_structural_doctor():
    base_dir = "c:/Users/eduso/Desktop/weblerim/odevgpt"
    src_dir = os.path.join(base_dir, "src")
    
    print("\n" + "="*60)
    print("🏗️  ODEVGPT YAPISAL BÜTÜNLÜK VE GÜVENLİK DOKTORU - v1.0")
    print("="*60)

    # 1. Yetim Bileşen Taraması (Orphaned Components)
    print("\n[1] 👻 Yetim Bileşen (Orphaned Components) Taraması...")
    all_components = glob.glob(os.path.join(src_dir, "components", "**", "*.tsx"), recursive=True)
    all_pages = glob.glob(os.path.join(src_dir, "pages", "**", "*.tsx"), recursive=True)
    all_ts_files = glob.glob(os.path.join(src_dir, "**", "*.tsx"), recursive=True) + \
                   glob.glob(os.path.join(src_dir, "**", "*.ts"), recursive=True)

    orphans = []
    for component in all_components:
        comp_name = os.path.basename(component).replace(".tsx", "")
        # Kendi dosyasını hariç tut, diğerlerinde ara
        found = False
        comp_pattern = re.compile(f"import.*{comp_name}")
        
        for f_path in all_ts_files:
            if os.path.abspath(f_path) == os.path.abspath(component):
                continue
            with open(f_path, 'r', encoding='utf-8', errors='ignore') as f:
                if comp_pattern.search(f.read()):
                    found = True
                    break
        if not found:
            orphans.append(comp_name)

    if orphans:
        print(f"  ⚠️  {len(orphans)} adet kullanılmayan bileşen tespit edildi (Silinebilir):")
        for o in orphans[:10]:
            print(f"    - {o}")
        if len(orphans) > 10: print("    ...")
    else:
        print("  ✅ Temiz: Tüm bileşenler aktif olarak kullanılıyor.")

    # 2. Güvenlik Taraması (Unprotected Routes)
    print("\n[2] 🛡️  Güvenlik Taraması (Unprotected Routes)...")
    app_tsx = os.path.join(src_dir, "App.tsx")
    with open(app_tsx, 'r', encoding='utf-8') as f:
        content = f.read()
        
    routes = re.findall(r'<Route path="([^"]+)"', content)
    protected_routes = re.findall(r'<Route\s+path="([^"]+)"\s+element=\{\s*<ProtectedRoute', content)
    
    unprotected = [r for r in routes if r not in protected_routes and r not in ['/', '/login', '/signup', '/blog', '/blog/:slug', '/sitemap', '*']]
    
    if unprotected:
        print(f"  🚨 KRİTİK: {len(unprotected)} rota ProtectedRoute dışında kalmış!")
        for u in unprotected:
            print(f"    - {u}")
    else:
        print("  ✅ Güvenli: Tüm hassas rotalar ProtectedRoute ile korunuyor.")

    # 3. Markalama Sızıntısı (Branding Leak)
    print("\n[3] 🏢 Markalama Sızıntısı (Branding Leak) Taraması...")
    leak_pattern = re.compile(r'>(OdevGPT)<', re.IGNORECASE)
    leaks = []
    
    for f_path in all_pages:
        with open(f_path, 'r', encoding='utf-8', errors='ignore') as f:
            if leak_pattern.search(f.read()):
                leaks.append(os.path.basename(f_path))

    if leaks:
        print(f"  💡 {len(leaks)} sayfada hardcoded 'OdevGPT' bulundu (Tenant Context önerilir):")
        for l in leaks[:5]:
            print(f"    - {l}")
    else:
        print("  ✅ Esnek: Statik marka ismi yerine dinamik yapı kullanılıyor.")

    print("\n" + "="*60)
    print("🏁 YAPISAL TEŞHİS TAMAMLANDI")
    print("="*60 + "\n")

if __name__ == "__main__":
    run_structural_doctor()
