import os
from pathlib import Path
from datetime import datetime

class TechDeepDiveReporter:
    def __init__(self, root_path):
        self.root = Path(root_path)
        self.output_file = self.root / "_local" / "ODEVGPT_TECHNICAL_DEEP_DIVE.txt"

    def read_file(self, path, limit=80):
        try:
            p = Path(path)
            if not p.exists(): return f"  [DOSYA BULUNAMADI: {p.name}]\n"
            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()[:limit]
                return "".join(lines)
        except Exception as e:
            return f"  [OKUMA HATASI: {e}]\n"

    def get_migration_summary(self):
        migration_dir = self.root / "supabase" / "migrations"
        if not migration_dir.exists():
            return "Migration klasörü bulunamadı.\n"
        migrations = sorted(list(migration_dir.glob("*.sql")), reverse=True)
        summary = ""
        for m in migrations[:12]:
            summary += f"\n{'='*60}\n"
            summary += f"📄 MIGRATION: {m.name}\n"
            summary += f"{'='*60}\n"
            summary += self.read_file(m, limit=60)
        return summary

    def generate_report(self):
        root = self.root
        report = []
        report.append("=" * 70)
        report.append("ODEVGPT — TAM TEKNİK MİMARİ & SİSTEM DUMP")
        report.append(f"Oluşturma: {datetime.now().strftime('%d.%m.%Y %H:%M')}")
        report.append("Sürüm: v2.1 — Security Hardened")
        report.append("=" * 70)

        # 1. Proje Yapısı
        report.append("\n\n[1] PROJE KLASÖR YAPISI (src/)")
        report.append("-" * 50)
        src = root / "src"
        for item in sorted(src.rglob("*")):
            if item.is_file() and item.suffix in [".ts", ".tsx", ".css"]:
                rel = item.relative_to(root)
                size = item.stat().st_size
                report.append(f"  {rel}  ({size} bytes)")

        # 2. AI Engine
        report.append("\n\n[2] AI ENGINE CORE (src/lib/ai.ts — ilk 200 satır)")
        report.append("-" * 50)
        report.append(self.read_file(root / "src" / "lib" / "ai.ts", limit=200))

        # 3. Supabase Migrations (Son 12 — en önemlileri)
        report.append("\n\n[3] VERITABANI MİGRASYONLARI (Son 12 — Yeniden Eskiye)")
        report.append("-" * 50)
        report.append(self.get_migration_summary())

        # 4. Package.json (Bağımlılıklar)
        report.append("\n\n[4] PROJE BAĞIMLILIKLARI (package.json)")
        report.append("-" * 50)
        report.append(self.read_file(root / "package.json", limit=60))

        # 5. Env Keys (sadece key isimleri, değerler değil)
        report.append("\n\n[5] ORTAM DEĞİŞKENLERİ (Sadece isimler, değerler gizli)")
        report.append("-" * 50)
        env_file = root / ".env"
        if env_file.exists():
            with open(env_file, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key = line.split("=")[0]
                        report.append(f"  {key}=***")
        else:
            report.append("  [.env dosyası bulunamadı — Supabase ortam değişkenleri kullanılıyor]")

        # 6. Güvenlik Özeti
        report.append("\n\n[6] GÜVENLİK MİMARİSİ ÖZETİ")
        report.append("-" * 50)
        report.append("""
  RLS (Row Level Security):
  - Tüm tablolar RLS aktif
  - Her sorgu get_my_tenant_id() üzerinden tenant izolasyonu
  - anon kullanıcısına hiçbir tablo erişimi yok (REVOKE ALL)
  - is_iam_super_admin() ile süper admin bypass — sadece holding seviyesi
  
  K-12 İçerik Güvenliği (ai.ts):
  - Katman 1: Blocked patterns (bomba, uyuşturucu, porn vb.) → tam engel
  - Katman 2: Warning patterns (şiddet, nefret) → uyarı notu
  - Sadece öğrenci facing özellikler denetleniyor
  
  Storage:
  - question_images bucket: okuma public, yükleme sadece authenticated
  - Silme: sadece dosya sahibi veya admin
  
  AI Key Güvenliği:
  - Tüm API keyler VITE_* env değişkenleri (frontend'de import.meta.env)
  - SERVICE_ROLE_KEY frontend kodunda YOK
  - Backend worker ayrı ortamda çalışıyor
""")

        with open(self.output_file, 'w', encoding='utf-8') as f:
            f.write("\n".join(report))
        print(f"✅ Teknik rapor güncellendi: {self.output_file}")
        return self.output_file

if __name__ == "__main__":
    reporter = TechDeepDiveReporter(r"c:\Users\eduso\Desktop\weblerim\odevgpt")
    reporter.generate_report()
